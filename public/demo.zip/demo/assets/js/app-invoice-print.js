"use strict";window.print();
